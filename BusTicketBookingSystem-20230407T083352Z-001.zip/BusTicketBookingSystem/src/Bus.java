import java.time.format.DateTimeFormatter;  
import java.time.LocalDate;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import org.jdesktop.swingx.JXDatePicker;
        
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Hp
 */
public class Bus extends javax.swing.JFrame implements ActionListener {

  
    public Bus() {
        initComponents();
        
    }
    int seatNo =0;
    private void initComponents() {

        lbTitle = new javax.swing.JLabel();
        lbstart = new javax.swing.JLabel();
        lbFrom = new javax.swing.JLabel();
        lbTo = new javax.swing.JLabel();
        txtSeats = new javax.swing.JTextField(20);
        lbSeats = new javax.swing.JLabel();
        lbPrice =new javax.swing.JLabel();
        txtStart = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        
        TA = new javax.swing.JTextArea();
        lbArrival = new javax.swing.JLabel();
        txtArrival = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jComboBoxFrom = new javax.swing.JComboBox<>();
        jComboBoxTo = new javax.swing.JComboBox<>();
        jComboBoxType= new javax.swing.JComboBox<>();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lbTitle.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        lbTitle.setText("Add New Bus ");

        lbstart.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lbstart.setText("Starttime");

        txtSeats.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
   

        lbSeats.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lbSeats.setText("NumSeats");

        lbPrice.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lbPrice.setText("Price");

        txtStart.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jButton1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton1.setText("BOOK");
        
        lbType.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
       

        lbArrival.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lbArrival.setText("Arrival Time");

        txtArrival.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txtPrice.setFont(new java.awt.Font("Tahoma", 0, 18)); 
        jButton2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton2.setText("Check Booking");
        
        lbFrom.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lbFrom.setText("From");

        lbTo.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lbTo.setText("To");

        jComboBoxFrom.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jComboBoxFrom.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ahmedabad", "Bangalore", "Bhopal", "Chennai", "Delhi", "Hyderabad", "Indore", "Jaipur", "Kanpur", "Kolkata", "Lucknow", "Mumbai", "Nagpur", "Patna", "Pimpri-Chinchwad", "Pune", "Surat", "Thane", "Vadodara", "Visakhapatnam\t" }));

        jComboBoxTo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jComboBoxTo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ahmedabad", "Bangalore", "Bhopal", "Chennai", "Delhi", "Hyderabad", "Indore", "Jaipur", "Kanpur", "Kolkata", "Lucknow", "Mumbai", "Nagpur", "Patna", "Pimpri-Chinchwad", "Pune", "Surat", "Thane", "Vadodara", "Visakhapatnam\t" }));


        jComboBoxType.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jComboBoxType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AC Sleeper", "Non AC Sleeper", "Luxury 3X2" }));

        
        btnAdd.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
       
        btnCancel.setFont(new java.awt.Font("Tahoma", 1, 18)); 
        setLayout(null);
        
        lbTitle.setBounds(250,30,300,30);
        add(lbTitle);
        
        lbFrom.setBounds(50,100,80,30);
        add(lbFrom);
        jComboBoxFrom.setBounds(170,100,120,30);
        add(jComboBoxFrom);
        
        lbTo.setBounds(330,100,80,30);
        add(lbTo);
        jComboBoxTo.setBounds(400,100,120,30);
        add(jComboBoxTo);
        
        lbSeats.setBounds(50,150,110,30);
        add(lbSeats);
        txtSeats.setBounds(170,150,120,30);
        add(txtSeats);
        
        lbType.setBounds(330,150,80,30);
        add(lbType);
        jComboBoxType.setBounds(400,150,120,30);
        add(jComboBoxType);
        
        
        lbstart.setBounds(50,200,110,30);
        add(lbstart);
        txtStart.setBounds(170,200,120,30);
        add(txtStart);
        
        
        lbArrival.setBounds(330,200,120,30);
        add(lbArrival);
        txtArrival.setBounds(430,200,120,30);
        add(txtArrival);
        
        lbPrice.setBounds(200,250,80,30);
        add(lbPrice);
        txtPrice.setBounds(280,250,80,30);
        add(txtPrice);
        
        btnAdd.setBounds(200,350,120,40);
        add(btnAdd);
        btnAdd.addActionListener(this);
        btnCancel.setBounds(330,350,120,40);
        add(btnCancel);
        btnCancel.addActionListener(this);
        setSize(700, 500);
        setVisible(true);
    }
      
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Bus.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Bus.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Bus.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Bus.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Bus().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea TA;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private com.toedter.calendar.JCalendar jCalendar2;
    private javax.swing.JComboBox<String> jComboBoxFrom;
    private javax.swing.JComboBox<String> jComboBoxTo;
    private javax.swing.JComboBox<String> jComboBoxType;
    private javax.swing.JLabel lbTitle;
    private javax.swing.JLabel lbFrom;
    private javax.swing.JLabel lbTo;
    private javax.swing.JLabel lbPrice;
    
    private javax.swing.JLabel lbType=new JLabel("Type");
    private javax.swing.JLabel lbstart;
    
    private javax.swing.JLabel lbSeats;
    private javax.swing.JLabel lbArrival;
        private javax.swing.JTextField txtSeats;
    private javax.swing.JTextField txtStart;
    private javax.swing.JTextField txtArrival;
    JTextField txtPrice=new JTextField(20);
    JButton btnAdd=new JButton("Add");
    JButton btnCancel=new JButton("Cancel");
    // End of variables declaration//GEN-END:variables
    
    
    public void clearall()
    {
    	
    	txtArrival.setText("");
    	txtSeats.setText("");
    	txtStart.setText("");
    	txtPrice.setText("");
    	jComboBoxFrom.setSelectedIndex(0);
    	jComboBoxTo.setSelectedIndex(0);
    	jComboBoxType.setSelectedIndex(0);
    	
    }
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==btnAdd)
		{
		Connection con = DB.connect();
		if(con==null)
			System.out.println("Connection is null");
		else
		{
			String source=jComboBoxFrom.getSelectedItem().toString();
			String dest=jComboBoxTo.getSelectedItem().toString();
			String start=txtStart.getText();
			String arrival=txtArrival.getText();
			int num=Integer.parseInt(txtSeats.getText());
			String type=jComboBoxType.getSelectedItem().toString();
			float price=Float.parseFloat(txtPrice.getText());
			
			try {
				PreparedStatement pstmt = con.prepareStatement("insert into busmaster(source,destination,no_seats,bustype,departure_time,arrival_time,price) values(?,?,?,?,?,?,?)");
				pstmt.setString(1, source);
				pstmt.setString(2, dest);
				pstmt.setInt(3, num);
				pstmt.setString(4, type);
				pstmt.setString(5, start);
				pstmt.setString(6, arrival);
				pstmt.setFloat(7, price);
				
				pstmt.executeUpdate();
				pstmt.close();
				con.close();
				JOptionPane.showMessageDialog(this, "done");
				clearall();
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			
			
		}
		}
		else 
		if(e.getSource()==btnCancel)
		{
			MainMenu m = new MainMenu();
			m.setVisible(true);
			this.setVisible(false);
		}
		
	}

    }
