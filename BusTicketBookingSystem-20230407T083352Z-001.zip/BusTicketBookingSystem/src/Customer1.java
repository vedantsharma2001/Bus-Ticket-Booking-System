
public class Customer1 {
	
	private int custid;
	private String custname;
	private String contact;
	private String address;
	private String city;
	private int zipcode;
	private String email;
	
	
	public Customer1() {
		// TODO Auto-generated constructor stub
	}


	public Customer1(int custid, String custname, String contact, String address, String city, int zipcode, String email) {
		super();
		this.custid = custid;
		this.custname = custname;
		this.contact = contact;
		this.address = address;
		this.city = city;
		this.zipcode = zipcode;
		this.email = email;
	}


	public int getCustid() {
		return custid;
	}


	public void setCustid(int custid) {
		this.custid = custid;
	}


	public String getCustname() {
		return custname;
	}


	public void setCustname(String custname) {
		this.custname = custname;
	}


	public String getContact() {
		return contact;
	}


	public void setContact(String contact) {
		this.contact = contact;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public int getZipcode() {
		return zipcode;
	}


	public void setZipcode(int zipcode) {
		this.zipcode = zipcode;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return custname;
	}

}
