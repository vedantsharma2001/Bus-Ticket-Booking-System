import java.time.format.DateTimeFormatter;  
import java.time.LocalDate;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import org.jdesktop.swingx.JXDatePicker;
        
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Hp
 */
public class Customer extends javax.swing.JFrame implements ActionListener {

  
    public Customer() {
        initComponents();
        
    }
    int seatNo =0;
    private void initComponents() {

      

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lbTitle.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        lbTitle.setText("Add New Customer ");

        lbName.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txtName.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
   
        lbContact.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
    
        lbAddress.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
       

        txtAddress.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        
        lbCity.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
       

        lbZip.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        

        txtName.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txtContact.setFont(new java.awt.Font("Tahoma", 0, 18)); 
        
        txtAddress.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txtContact.setFont(new java.awt.Font("Tahoma", 0, 18));
        txtCity.setFont(new java.awt.Font("Tahoma", 0, 18));
        txtZip.setFont(new java.awt.Font("Tahoma", 0, 18));
        
        lbEmail.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txtEmail.setFont(new java.awt.Font("Tahoma", 0, 18)); 
        
        
        
        
        btnAdd.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
       
        btnCancel.setFont(new java.awt.Font("Tahoma", 1, 18)); 
        setLayout(null);
        
        lbTitle.setBounds(250,30,300,30);
        add(lbTitle);
        
        lbName.setBounds(50,100,80,30);
        add(lbName);
        txtName.setBounds(170,100,120,30);
        add(txtName);
        
        lbContact.setBounds(330,100,80,30);
        add(lbContact);
        txtContact.setBounds(400,100,120,30);
        add(txtContact);
        
        lbAddress.setBounds(50,150,110,30);
        add(lbAddress);
        txtAddress.setBounds(170,150,120,30);
        add(txtAddress);
        		
        
        lbCity.setBounds(330,150,80,30);
        add(lbCity);
        txtCity.setBounds(400,150,120,30);
        add(txtCity);
        
        
        lbZip.setBounds(50,200,110,30);
        add(lbZip);
        txtZip.setBounds(170,200,120,30);
        add(txtZip);
        
      
        lbEmail.setBounds(330,200,120,30);
        add(lbEmail);
        txtEmail.setBounds(400,200,120,30);
        add(txtEmail);
        
       
        btnAdd.setBounds(200,350,120,40);
        add(btnAdd);
        btnAdd.addActionListener(this);
        btnCancel.setBounds(330,350,120,40);
        add(btnCancel);
        btnCancel.addActionListener(this);
        setSize(700, 500);
        setVisible(true);
    }
      
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Customer().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
 
    private javax.swing.JLabel lbTitle=new JLabel();
    private javax.swing.JLabel lbName=new JLabel("Name");
    private javax.swing.JLabel lbContact=new JLabel("Contact");;
    private javax.swing.JLabel lbAddress=new JLabel("Address");
    private javax.swing.JLabel lbCity=new JLabel("City");
    private javax.swing.JLabel lbZip=new JLabel("Zipcode");
    private javax.swing.JLabel lbEmail=new JLabel("Email");
    
   
    private javax.swing.JTextField txtName=new JTextField(20);
    private javax.swing.JTextField txtContact=new JTextField(20);;
    private javax.swing.JTextField txtAddress=new JTextField(20);;
    JTextField txtCity=new JTextField(20);
    JTextField txtZip=new JTextField(20);
    JTextField txtEmail=new JTextField(20);
    
    JButton btnAdd=new JButton("Add");
    JButton btnCancel=new JButton("Cancel");
    // End of variables declaration//GEN-END:variables
    
    
    public void clearall()
    {
    	
    	txtName.setText("");
    	txtAddress.setText("");
    	txtCity.setText("");
    	txtZip.setText("");
    	txtContact.setText("");
    	txtEmail.setText("");
    	
    }
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==btnAdd)
		{
		Connection con = DB.connect();
		if(con==null)
			System.out.println("Connection is null");
		else
		{
			String name=txtName.getText();
			String contact=txtContact.getText();
		    String addr=txtAddress.getText();
			String city=txtCity.getText();
			int zip=Integer.parseInt(txtZip.getText());
			String email=txtEmail.getText();
			
			
			try {
				PreparedStatement pstmt = con.prepareStatement("insert into customer(custname,contact,address,city,zipcode,email) values(?,?,?,?,?,?)");
				pstmt.setString(1, name);
				pstmt.setString(2,contact);
				pstmt.setString(3,addr);
				pstmt.setString(4, city);
				pstmt.setInt(5, zip);
				pstmt.setString(6, email);
				pstmt.executeUpdate();
				pstmt.close();
				con.close();
				JOptionPane.showMessageDialog(this, "done");
				clearall();
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			
			
		}
		}
		else 
		if(e.getSource()==btnCancel)
		{
			MainMenu m = new MainMenu();
			m.setVisible(true);
			this.setVisible(false);
		}
		
	}

    }
