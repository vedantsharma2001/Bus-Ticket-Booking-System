import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class MainMenu extends JFrame implements ActionListener{
	
	JButton btnBus = new JButton("Bus Management");
	JButton btnBooking = new JButton("Booking"); 
	JButton btnAccount = new JButton("Account"); 
	JButton btnCustomer = new JButton("Customer");
	JButton btnQuit = new JButton("Quit");
	
	public MainMenu()
	{
		setSize(350,400);
		setVisible(true);
		setLocation(500,300);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		setLayout(new GridLayout(6,1,50,30));
		Font f = new Font("Tahoma", 1, 16);
		JLabel lbTitle = new JLabel("Main Menu",JLabel.CENTER);
		lbTitle.setFont(f);
		add(lbTitle);
		add(btnBus);
		add(btnBooking);
		add(btnAccount);
		add(btnCustomer);
		add(btnQuit);
		
		btnBus.addActionListener(this);
		btnBooking.addActionListener(this);
		btnAccount.addActionListener(this);
		btnCustomer.addActionListener(this);
		btnQuit.addActionListener(this);
		
	}

	public static void main(String[] args) {
		MainMenu f = new MainMenu();

	}

	@Override
	public Insets getInsets() {
		// TODO Auto-generated method stub
		return new Insets(50,20,20,20);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		 if(e.getSource()==btnBus)
		  {
			setVisible(false);
			Bus b = new Bus();
			}
		 else
			 if(e.getSource()==btnCustomer)
			  {
				setVisible(false);
				Customer c = new Customer();
				}
			 else
				 if(e.getSource()==btnBooking)
				  {
					setVisible(false);
					Booking bk = new Booking();
					
					bk.setVisible(true);
					}
				 else
					 if(e.getSource()==btnAccount)
					 {
						 setVisible(false);
						 Account A = new Account();
						 A.setVisible(true);
					 }
					 else
	  if(e.getSource()==btnQuit)
	  {
		 
		setVisible(false);
		dispose();
		System.exit(0);
		}
		  
			  
			  
	  }  
		
	}


