import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class LoginForm extends JFrame implements ActionListener{
	
	JLabel lbTitle = new JLabel("Login");
	JLabel lbUser = new JLabel("Username");
	JTextField txtUser = new JTextField(20);
	JLabel lbPass = new JLabel("Password");
	JPasswordField txtPass = new JPasswordField();
	JButton btnLogin = new JButton("Login"); 
	JButton btnCancel = new JButton("Cancel"); 
	
	public LoginForm()
	{
		setSize(350,300);
		setVisible(true);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		setLayout(null);
		lbTitle.setBounds(130,50,200,30);
		lbUser.setBounds(50, 100,80, 30);
		lbTitle.setFont(new Font("Tahoma", 1, 18));
		add(lbTitle);
		lbUser.setFont(new Font("Tahoma", 1, 14));
		add(lbUser);
		txtUser.setBounds(140, 100,120, 30);
		add(txtUser);
		
		lbPass.setBounds(50, 150,80, 30);
		lbPass.setFont(new Font("Tahoma", 1, 14));
		add(lbPass);
		txtPass.setBounds(140, 150,120, 30);
		add(txtPass);
		btnLogin.setBounds(50,200,80,30);
		add(btnLogin);
		btnCancel.setBounds(140,200,80,30);
		add(btnCancel);
		
		btnLogin.addActionListener(this);
		btnCancel.addActionListener(this);
	}

	public static void main(String[] args) {
		LoginForm f = new LoginForm();
		f.setLocation(500,200);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
	  if(e.getSource()==btnLogin)
	  {
		  if(txtUser.getText()==null || txtUser.getText().length()==0)
			  JOptionPane.showMessageDialog(this,"Username cannot be blank !");
		  else
			  if(txtPass.getText()==null || txtPass.getText().length()==0)
				  JOptionPane.showMessageDialog(this,"Password cannot be blank !");
			  else
		  if(txtUser.getText().equals("admin") && txtPass.getText().equals("admin"))
		  {
			  setVisible(false);
			  MainMenu b = new MainMenu();
			  b.setVisible(true);
		  }
		  else
			 JOptionPane.showMessageDialog(this,"Incorrect username or password !");

			  
			  
	  }  
		
	}

}
